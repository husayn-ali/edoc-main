<?php
session_start();

if (!isset($_SESSION["user"]) || $_SESSION["user"] == "" || $_SESSION['usertype'] != 'a') {
    header("location: ../login.php");
    exit;
}

include("../connection.php");

$doctorrow = $database->query("SELECT * FROM doctor;");
$patientrow = $database->query("SELECT * FROM patient;");
$appointmentrow = $database->query("SELECT * FROM appointment;");
$schedulerow = $database->query("SELECT * FROM schedule;");
?>

<?php include("../includes/header.php"); ?>
<?php include("../includes/navbar.php"); ?>
<div class="container-fluid page-body-wrapper">
  <?php include("../includes/sidebar.php"); ?>

  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
        <div class="col-md-3 grid-margin stretch-card">
          <div class="card">
            <div class="card-body text-center">
              <h3><?php echo $doctorrow->num_rows; ?></h3>
              <p class="text-muted">Doctors</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 grid-margin stretch-card">
          <div class="card">
            <div class="card-body text-center">
              <h3><?php echo $patientrow->num_rows; ?></h3>
              <p class="text-muted">Patients</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 grid-margin stretch-card">
          <div class="card">
            <div class="card-body text-center">
              <h3><?php echo $appointmentrow->num_rows; ?></h3>
              <p class="text-muted">New Bookings</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 grid-margin stretch-card">
          <div class="card">
            <div class="card-body text-center">
              <h3><?php echo $schedulerow->num_rows; ?></h3>
              <p class="text-muted">Today Sessions</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Upcoming Appointments Table -->
      <div class="row">
        <div class="col-lg-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Upcoming Appointments</h4>
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Appointment Number</th>
                      <th>Patient Name</th>
                      <th>Doctor</th>
                      <th>Session</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $today = date('Y-m-d');
                    $nextweek = date("Y-m-d", strtotime("+1 week"));
                    $sqlmain = "SELECT appointment.appoid, schedule.title, doctor.docname, patient.pname, appointment.apponum 
                                FROM schedule 
                                INNER JOIN appointment ON schedule.scheduleid = appointment.scheduleid 
                                INNER JOIN patient ON patient.pid = appointment.pid 
                                INNER JOIN doctor ON schedule.docid = doctor.docid 
                                WHERE schedule.scheduledate >= '$today' AND schedule.scheduledate <= '$nextweek' 
                                ORDER BY schedule.scheduledate DESC";

                    $result = $database->query($sqlmain);
                    if ($result->num_rows == 0) {
                      echo '<tr><td colspan="4" class="text-center">No upcoming appointments</td></tr>';
                    } else {
                      while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['apponum']}</td>
                                <td>{$row['pname']}</td>
                                <td>{$row['docname']}</td>
                                <td>{$row['title']}</td>
                              </tr>";
                      }
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- Upcoming Sessions Table -->
        <div class="col-lg-6 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Upcoming Sessions</h4>
              <div class="table-responsive">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>Session Title</th>
                      <th>Doctor</th>
                      <th>Scheduled Date & Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $sqlmain = "SELECT schedule.title, doctor.docname, schedule.scheduledate, schedule.scheduletime 
                                FROM schedule 
                                INNER JOIN doctor ON schedule.docid = doctor.docid 
                                WHERE schedule.scheduledate >= '$today' AND schedule.scheduledate <= '$nextweek' 
                                ORDER BY schedule.scheduledate DESC";

                    $result = $database->query($sqlmain);
                    if ($result->num_rows == 0) {
                      echo '<tr><td colspan="3" class="text-center">No upcoming sessions</td></tr>';
                    } else {
                      while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['title']}</td>
                                <td>{$row['docname']}</td>
                                <td>{$row['scheduledate']} {$row['scheduletime']}</td>
                              </tr>";
                      }
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div> <!-- content-wrapper -->
    <?php include("../includes/footer.php"); ?>
  </div> <!-- main-panel -->
</div> <!-- page-body-wrapper -->

</body>
</html>
