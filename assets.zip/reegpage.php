<?php  include_once("./includes/header.php")  ?>    
<?php  include_once("./includes/navbar.php")  ?> 
<?php  include_once("./includes/sidebar.php")  ?> 
    <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title"> Form elements </h3>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Forms</a></li>
                <li class="breadcrumb-item active" aria-current="page">Form elements</li>
              </ol>
            </nav>
          </div>
          <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">

                </div>
              </div>
            </div>
          </div>
<?php  include_once("./includes/footer.php")  ?> 